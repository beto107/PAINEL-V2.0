<?php

include("/var/www/html/pages/system/pass.php");

$DB_host = "localhost";
$DB_user = "root";
$DB_pass = $pass;
$DB_name = "painel";

?>